using Godot;

[GlobalClass]
public partial class HitboxComponent : Area2D
{
	[Export] public int Damage { get; set; } = 1;

	public override void _Ready()
	{
		// Conectar la señal nativa de Area2D
		AreaEntered += OnAreaEntered;
		// Por defecto, el hitbox debería estar apagado hasta que se ataque
		Monitoring = false;
	}

	private void OnAreaEntered(Area2D area)
	{
		// Buscamos si el área que tocamos es un HealthComponent
		if (area is HealthComponent health)
		{
			health.TakeDamage(Damage);
		}
	}
}
