using Godot;
using System;

public partial class PRUEBA : CharacterBody2D
{
	[Export] public float Speed { get; set; } = 250.0f;
	[Export] public float AttackSpeed { get; set; } = 1.0f;

	private AnimationPlayer _animationPlayer;
	private Sprite2D _sprite;
	private HealthComponent _health;
	private bool _isAttacking = false;

	public override void _Ready()
	{
		_animationPlayer = GetNode<AnimationPlayer>("AnimationPlayer");
		_sprite = GetNode<Sprite2D>("Sprite2D"); // Asegúrate que se llame así en tu escena
		_health = GetNode<HealthComponent>("HealthComponent");
		
		_health.Died += OnDied;
		AddToGroup("Player");
	}

	public override void _PhysicsProcess(double delta)
	{
		if (_isAttacking) return;

		Vector2 input = Input.GetVector("ui_left", "ui_right", "ui_up", "ui_down");
		Velocity = input * Speed;
		MoveAndSlide();

		if (input.Length() > 0)
		{
			_animationPlayer.Play("run");

			// LÓGICA DE GIRO DIRECTA
			if (input.X != 0)
			{
				// Usamos la escala del Sprite. 
				// Math.Sign devuelve -1 si vas a la izquierda y 1 a la derecha.
				Vector2 nuevaEscala = _sprite.Scale;
				nuevaEscala.X = Math.Abs(nuevaEscala.X) * Math.Sign(input.X);
				_sprite.Scale = nuevaEscala;

				// Si tienes un Hitbox que también debe girar:
				var hitbox = GetNodeOrNull<Area2D>("HitboxComponent");
				if (hitbox != null) {
					Vector2 hScale = hitbox.Scale;
					hScale.X = Math.Abs(hScale.X) * Math.Sign(input.X);
					hitbox.Scale = hScale;
				}
			}
		}
		else
		{
			_animationPlayer.Play("idle");
		}

		if (Input.IsActionJustPressed("ui_accept")) StartAttack();
	}

	private void StartAttack()
	{
		_isAttacking = true;
		_animationPlayer.Play("attack", customSpeed: AttackSpeed);
		
		var hitbox = GetNodeOrNull<Area2D>("HitboxComponent");
		if (hitbox != null) hitbox.Monitoring = true;

		GetTree().CreateTimer(0.4f / AttackSpeed).Timeout += OnAttackFinished;
	}

	private void OnAttackFinished()
	{
		_isAttacking = false;
		var hitbox = GetNodeOrNull<Area2D>("HitboxComponent");
		if (hitbox != null) hitbox.Monitoring = false;
	}

	private void OnDied()
	{
		GD.Print("Jugador eliminado");
		QueueFree();
	}
}
