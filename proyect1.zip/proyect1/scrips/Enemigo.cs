using Godot;
using System;

public partial class Enemigo : CharacterBody2D
{
	[Export] public float Speed { get; set; } = 150.0f;
	[Export] public float AttackDistance { get; set; } = 55.0f;
	[Export] public float DetectionRange { get; set; } = 400.0f;

	private AnimationPlayer _anim;
	private Sprite2D _sprite;
	private HealthComponent _health;
	private CharacterBody2D _player;
	
	private bool _isAttacking = false;
	private bool _isDead = false;
	private bool _isStunned = false; // Nueva bandera de estado

	public override void _Ready()
	{
		_anim = GetNode<AnimationPlayer>("AnimationPlayer");
		_sprite = GetNode<Sprite2D>("Sprite2D");
		_health = GetNode<HealthComponent>("HealthComponent");

		if (_health != null)
		{
			_health.Died += OnDied;
			// ASUNCIÓN: Tu HealthComponent tiene una señal llamada "Hurt" o similar.
			// Si no, llama a OnHurt() desde donde gestiones el daño.
			_health.Connect("Hurt", Callable.From(OnHurt)); 
		}

		_player = GetTree().GetFirstNodeInGroup("Player") as CharacterBody2D;
	}

	public override void _PhysicsProcess(double delta)
	{
		// Si está muerto o aturdido, no procesamos movimiento ni IA
		if (_isDead || _isStunned || _player == null || !GodotObject.IsInstanceValid(_player))
			return;

		float distance = GlobalPosition.DistanceTo(_player.GlobalPosition);
		UpdateFacingDirection();

		if (distance > DetectionRange || _isAttacking)
		{
			Velocity = Vector2.Zero;
			if (!_isAttacking) _anim.Play("idle");
			MoveAndSlide();
			return;
		}

		Vector2 direction = (_player.GlobalPosition - GlobalPosition).Normalized();

		if (distance > AttackDistance)
		{
			Velocity = direction * Speed;
			_anim.Play("run");
		}
		else
		{
			Velocity = Vector2.Zero;
			StartAttack();
		}

		MoveAndSlide();
	}

	private void UpdateFacingDirection()
	{
		if (_player == null || _isStunned) return;
		Vector2 direction = (_player.GlobalPosition - GlobalPosition).Normalized();
		if (Mathf.Abs(direction.X) > 0.1f)
		{
			_sprite.FlipH = direction.X < 0;
		}
	}

	// --- NUEVA LÓGICA DE DAÑO Y RECUPERACIÓN ---

	private void OnHurt()
	{
		if (_isDead || _isStunned) return;

		_isStunned = true;
		Velocity = Vector2.Zero;
		
		// 1. Ejecutar animación de recibir daño
		_anim.Play("hurt"); 

		// 2. Esperar 10 segundos
		GetTree().CreateTimer(10.0f).Timeout += () => 
		{
			if (!_isDead) RecoverFromStun();
		};
	}

	private void RecoverFromStun()
	{
		// 3. Ejecutar animación de "vuelta al combate"
		_anim.Play("wakeup"); // Cambia "wakeup" por el nombre real de tu animación

		// Esperamos a que la animación termine para devolver el control
		// Usamos Once para que solo se ejecute una vez al terminar
		_anim.AnimationFinished += OnWakeupFinished;
	}

	private void OnWakeupFinished(StringName animName)
	{
		if (animName == "wakeup")
		{
			_anim.AnimationFinished -= OnWakeupFinished;
			_isStunned = false; // Ahora el enemigo puede volver a perseguir
		}
	}

	// -------------------------------------------

	private void StartAttack()
	{
		if (_isAttacking || _isDead || _isStunned) return;
		_isAttacking = true;
		_anim.Play("attack");

		var hitbox = GetNodeOrNull<HitboxComponent>("HitboxComponent");
		if (hitbox != null) hitbox.Monitoring = true;

		GetTree().CreateTimer(0.6f).Timeout += () =>
		{
			_isAttacking = false;
			if (hitbox != null) hitbox.Monitoring = false;
		};
	}

	private void OnDied()
	{
		if (_isDead) return;
		_isDead = true;
		_isStunned = false; // Prioridad a la muerte
		Velocity = Vector2.Zero;
		_anim.Stop();
		_anim.Play("death");

		var collision = GetNodeOrNull<CollisionShape2D>("CollisionShape2D");
		if (collision != null)
			collision.SetDeferred(CollisionShape2D.PropertyName.Disabled, true);

		GD.Print("El enemigo ha caído.");
	}
}
